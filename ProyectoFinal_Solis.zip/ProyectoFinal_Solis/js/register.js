
//// PASOS-A-SEGUIR --> Simulador: ////

/*
1. Después de dar clic en el botón: 'Iniciar Sesión' (index.html). Al ingresar a esta pantalla, se abre un 'Modal' para 'Inciar sesión', con los espacios y/o 'inputs' para incluir:

> Usuario
> Contraseña
> Botón: 'Inciar sesión'
> Botón: 'Registrarse'

  - Si el usuario ya tiene 'usuario/contraseña; registrados, se ingresan los datos en 'inputs' correspondientes
  y se cliquea el botón: 'Inciar sesión'
  - Pero si todavía no se cuenta con un 'usuario/contraseña, se hace clic en el Botón: 'Registrarse'. Inmediatamente,
  se cierra el 'Modal' y se visualiza la página/form, para 'Registrarse'.

2. El fomulario para 'Registrarse' incluye varios espacios y/o 'inputs':

> Nombre
> Usuario
> Email
> Contraseña

  - Si se ingresan todos los datos/inputs para 'Registrarse', y luego se hace clic en el botón: 'Registarse,
  los datos ingresados (nuevo usuario) se almacena/guarda en el 'Local Storage'.
  - Seguidamente, si se da clic en el botón: 'Iniciar sesión', se abre de nuevo el 'Modal' (se recuperan los datos
  del nuevo usuario) se ingresa el 'nuevo usuario' en los campos/inputs:

    * Usuario
    * Contraseña
    
      - Luego, cliquea el botón: 'Iniciar Sesión' (Login) y se ingresa a la página: 'Tienda en línea/Productos' (shop.html), con el nuevo usuario creado.
*/



//// REGISTER | LOGIN ////

//Modal
// Función para mostrar el modal de inicio de sesión.
const showLoginModal = () => {
  const loginModalButton = document.getElementById('login-modal-button');
  if (loginModalButton) {
    loginModalButton.click();
  }
};

document.addEventListener("DOMContentLoaded", () => {
  showLoginModal(); // Llama a la función showLoginModal cuando se ha cargado el contenido del DOM.
});

class User {
  constructor(name, username, email, password) {
    this.name = name;
    this.username = username;
    this.email = email;
    this.password = password;
  }
}

const formRegister = document.getElementById("formRegister");
const nombreInput = document.getElementById("nombreInput");
const userRegInput = document.getElementById("userRegInput");
const emailInput = document.getElementById("emailInput");
const passRegInput = document.getElementById("passRegInput");

document.getElementById("registrarseAhora").addEventListener('click', (event) => {
  event.preventDefault();

  if (nombreInput.value === "" || userRegInput.value === "" || emailInput.value === "" || passRegInput.value === "") {
    // Muestra una alerta si los campos del formulario están vacíos.
    swal.fire({
      title: 'Por favor, complete todos los campos antes de continuar.',
      icon: 'error',
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });
    return;
  }

  const newUser = new User(
    nombreInput.value,
    userRegInput.value,
    emailInput.value,
    passRegInput.value
  );

  localStorage.setItem("currentUser", JSON.stringify(newUser)); // Guarda el usuario en el almacenamiento local.
  console.log(JSON.parse(localStorage.getItem("currentUser"))); // Imprime el usuario guardado en la consola.

  formRegister.reset(); // Limpia los campos del formulario de registro.

  // Muestra una alerta de registro exitoso.
  swal.fire({
    title: '¡Registro exitoso!',
    text: 'Usted se ha registrado satisfactoriamente, ya puede iniciar sesión.',
    icon: 'success',
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000
  });
  return;
});

const loginForm = document.getElementById("ingresar");
const loginUsername = document.getElementById("login-username");
const loginPassword = document.getElementById("login-password");
const errorMessage = document.getElementById("errorMessage");

const loginButton = document.querySelector("#login-modal .btn-success");
if (loginButton) {
  loginButton.addEventListener("click", () => {
    const storedUser = JSON.parse(localStorage.getItem("currentUser"));
    const enteredUsername = loginUsername.value;
    const enteredPassword = loginPassword.value;

    if (storedUser && enteredUsername === storedUser.username && enteredPassword === storedUser.password) {
      // Redirecciona a la página 'shop.html' si los datos de inicio de sesión son correctos.
      window.location.href = "shop.html";
    } else {
      errorMessage.textContent = "¡Usuario no encontrado! Debes dar click en 'Registrarse'."; // Muestra un mensaje de error si el usuario no existe.
    }

    loginForm.reset(); // Limpia los campos del formulario de inicio de sesión.
  });
}

// Utilizando arrow function en la función cerrarModal
const cerrarModal = () => {
  $('#login-modal').modal('hide'); // Cierra el modal de inicio de sesión al hacer clic en el enlace de registro.
};