
//// PASOS-A-SEGUIR --> Simulador: ////

/*
1. En esta pantalla se visualizan los productos disponibles en la 'Tienda en línea'(ésta tienda virtual muestra productos,
  permite buscarlos y agregarlos al carrito de compras), conformada por lo siguiente:

  > Filtro de productos.

    - A través de un 'input'/campo y un botón: 'Buscar', se pueden filtrar los productos disponibles; ya sea, incluyendo parte
    o completamente el nombre del producto en cuestión.
    - Además, si se encuentra el producto y el usuario lo quiere comprar, puede agregarlo al 'Carrito de compras' (en botón: 'Añadir al carrito') después de filtrado.
    - Si no existe o no está disponible el producto en 'stock' sale un mensaje que dice: '¡Producto no encontrado!'
    
  > Listados de productos.

    - Son una serie de 'Cards' conformadas por:

      * Una imagen del producto.
      * Título y Precio.
      * Botón: 'Añadir al carrito'.

        >> Al cliquear este botón como su nombre lo dice, se añaden o agregan los productos seleccionados al carrito de compras.
    
  > Carrito de compras.

    - Está sección esta conformada por:

      * Título: Carrito.
      * Títulos o encabezados: Nombre - Precio - Cantidad - Borrar.
      * Espacio de productos agregados.
      
        >> En esta sección de la página, se ingresan los productos seleccionados; cada vez que se agrega un elemento al carrito,
         se suma su precio al total.
            >>> Cantidad. Contiene: Cantidad de artículos o productos elegidos, + botón 'agregar', + botón 'eliminar' (número de productos agregados).
            >>> Borrar. Contiene: Botón de 'borrar', los productos incluidos en 'carrito'. 

      * Total/monto (ingresado).

      * Botón: 'Vaciar carrito'.

        >> Este botón permite 'vaciar' el carrito de compras y/o productos agregados al mismo (queda en: 0)

      * Botón: 'Comprar productos'.

        >> Si se da clic en el botón antes de ingresar productos al carrito, aparece un mensaje que dice:
        'Oops.. Debes agregar productos al carrito antes de realizar la compra.'
        >> Si el botón se cliquea después de agregar productos al carrito, se muestra el mensaje:
        '¿Estás seguro/a de que deseas finalizar la orden?'; 
            >>> Se puede, elegir 'Si': 
                - Mensaje (bajo el 'carrito'): 
                    "FitMarket
                    Pedido# XXX
                    ¡Gracias XXX! Su pedido ha sido realizado con éxito.
                    Nos pondremos en contacto con usted en menos de 24 horas a través del correo electrónico proporcionado: XXX
                    ¡Gracias por su compra!"

                      ->Lo anterior, porque este simulador es sobre: 'una Tienda virtual con servicio de Delivery para los clientes del GAM'.

                - Mensaje 'sweetalert';
                    'La orden ha sido procesada exitosamente.'
                  
            >>> Elegir, 'Seguir comprando':
                - Si hay productos ingresados al carrito, se mantienen; para seguir comprando.

  > Si finalmente se decide cerrar sesión (botón), aparece un mensaje que dice:
    - '¿Está seguro/a de que desea cerrar sesión?', Si la respuesta es:

      * 'Si'. Redirige al usuario a: página de inicio ó 'home'.
    
      * 'Continuar comprando'. El usuario se mantiene o permanece en la tienda ó página 'shop.html'.

//--Fin--//  
*/


//// SHOP ////

//variables.
const btnSearch = document.querySelector("#btnSearch");
const inputIngreso = document.querySelector("#ingreso");
const contenedor = document.querySelector("#contenedor");
const carrito = document.querySelector("#carrito");
const totalSpan = document.querySelector("#total");
const botonVaciar = document.querySelector("#boton-vaciar");
const mensajeCompra = document.querySelector("#mensajeCompra");
let total = 0;

// Funciones de búsqueda.
function buscarProducto(arr, filtro) {
  return arr.find((el) => el.nombre.toLowerCase().includes(filtro.toLowerCase()));
}


// Función para mostrar productos.
function mostrarProductos(arr) {
  let html = "";

  // Iterar sobre cada elemento del array.
  arr.forEach((el) => {
    // Generar el HTML para cada producto.
    html += `
      <div class="col-12 col-md-6 col-lg-4 mb-3">
        <div class="card col">
          <img src="./img/${el.img}" alt="${el.nombre}">
          <div class="card-body">
            <h3 class="card-title">${el.nombre}</h3>
            <p class="precio" data-precio="${el.precio}">Precio: $${el.precio}</p>
            <div class="card-action d-grid gap-2">
              <button id="${el.id}" class="btn btn-success btn-comprar" data-nombre="${el.nombre}" data-precio="${el.precio}">Añadir al carrito</button>
            </div>
          </div>
        </div>
      </div>
    `;
  });

  // Obtener el contenedor donde se mostrarán los productos.
  const contenedor = document.getElementById("contenedor");

  // Utilizar operador ternario para mostrar mensaje en caso de carrito vacío.
  contenedor.innerHTML = arr.length > 0 ? html : "<p><strong>¡Producto no encontrado!</strong></p>";

  // Asignar eventos a los botones de compra
  asignarEventosCompra();
}



//Procesar orden en carrito.
const procesarOrden = async () => {
  // Verifica si el carrito contiene elementos li.
  if (document.querySelectorAll('#carrito li').length > 0) {
    // Si el carrito tiene elementos li, muestra un mensaje de confirmación con sweetalert.
    const result = await Swal.fire({
      title: '¿Estás seguro/a de que deseas finalizar la orden?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: 'Si',
      denyButtonText: `Seguir comprando`,
    });

    if (result.isConfirmed) {
      // Obtiene el email y nombre del usuario del local storage.
      const currentUser = JSON.parse(localStorage.getItem('currentUser'));
      const { email, name } = currentUser;

      // Genera un número aleatorio de 4 dígitos.
      const randomPedido = Math.floor(1000 + Math.random() * 9000);

      // Muestra el mensaje de éxito con el nombre, email y número de pedido.
      document.getElementById('mensajeCompra').innerHTML = `
        <hr>
        <h2><strong>FitMarket</strong></h2>
        <p>Pedido # ${randomPedido}</p>
        <h5><i class="far fa-check-circle"></i> ¡Gracias ${name}! Su pedido ha sido realizado con éxito.</h5>
        <p>Nos pondremos en contacto con usted en menos de 24 horas a través del correo electrónico proporcionado: <span>${email}</span></p>
        <p>¡Gracias por su compra!</p>
      `;

      // Borra los datos del key 'productos' del local storage.
      localStorage.removeItem('productos');

      // Ejemplo: mostrar mensaje de éxito.
      Swal.fire({
        title: 'Orden procesada',
        text: 'La orden ha sido procesada exitosamente.',
        icon: 'success',
        toast: true,
        position: 'top-end',
        timer: 3000,
        showConfirmButton: false
      });

      // Actualizar el total a cero.
      document.getElementById('total').textContent = '0';

      // Eliminar los elementos li del carrito.
      const carrito = document.getElementById('carrito');
      while (carrito.firstChild) {
        carrito.removeChild(carrito.firstChild);
      }
    } else if (result.isDenied) {
      // Si el usuario decide seguir comprando, realiza las acciones necesarias.
      // ...
    }
  } else {
    // Si el carrito está vacío, muestra un mensaje de error con swal.fire.
    Swal.fire({
      title: 'Oops..',
      text: 'Debes agregar productos al carrito antes de realizar la compra.',
      icon: 'error',
      toast: true,
      position: 'top-end',
      timer: 3000,
      showConfirmButton: false
    });
  }
};


// Asignar evento de clic a la función de procesar orden.
document.getElementById('comprarProductos').addEventListener('click', procesarOrden);


// Función para vaciar el carrito.
function vaciarCarrito() {
while (carrito.firstChild) {
carrito.removeChild(carrito.firstChild);
}
total = 0;
 totalSpan.innerHTML = total.toFixed(2);
}


// Evento de clic para el botón "Vaciar".
botonVaciar.addEventListener("click", vaciarCarrito);


// Jalar datos a través de fetch.
const loader = document.getElementById("loader"); // Obtener el elemento del loader.

// Función para cargar los datos.
const loadData = async () => {
  try {
    loader.style.display = "block"; // Mostrar el elemento del loader.

    // Hacer la solicitud para obtener los datos del archivo JSON.
    const res = await fetch("./data/data.json");
    const data = await res.json(); // Convertir la respuesta en formato JSON.

    mostrarProductos(data); // Llamar a la función mostrarProductos con los datos obtenidos.

    loader.style.display = "none"; // Ocultar el elemento del loader una vez que se han cargado los datos.
  } catch (err) {
    console.log(err); // Mostrar cualquier error en la consola.
    loader.style.display = "none"; // Ocultar el elemento del loader en caso de error.
  }
};

// Función para mostrar el mensaje de bienvenida.
const showWelcomeMessage = () => {
  setTimeout(() => {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));

    if (currentUser && !localStorage.getItem(`welcomeMessageShown_${currentUser.username}`)) {
      const name = currentUser.name;

      Swal.fire({
        title: `Bienvenido/a a Fitmarket ${name}! `,
        icon: 'success',
        toast: true,
        position: 'top-start',
        timer: 3000,
        showConfirmButton: false
      });

      localStorage.setItem(`welcomeMessageShown_${currentUser.username}`, true); // Establecer una bandera para indicar que el mensaje de bienvenida se ha mostrado para este usuario.
    }
  }, 2000);
};

setTimeout(loadData, 2000); // Esperar 2 segundos y luego cargar los datos.
window.addEventListener('load', showWelcomeMessage); // Cuando la página se ha cargado completamente, mostrar el mensaje de bienvenida.



// Función para filtrar productos.
function filtrarProducto(arr, filtro) {
  return arr.filter((el) => el.nombre.toLowerCase().includes(filtro.toLowerCase()));
}


// Función para buscar productos.
const buscar = () => {
  // Obtener el término de búsqueda del input con id 'ingreso' y quitar espacios en blanco.
  const searchTerm = document.querySelector("#ingreso").value.trim();
  
  // Llamar a la API para obtener los datos del archivo 'data.json'
  fetch("./data/data.json")
    .then((res) => res.json()) // Parsear la respuesta como un objeto JSON.
    .then((data) => filtrarProducto(data, searchTerm)) // Filtrar los productos en base al término de búsqueda.
    .then((filteredProducts) => mostrarProductos(filteredProducts)) // Mostrar los productos filtrados.
    .catch((err) => console.log(err)); // Manejar errores en caso de que la llamada a la API falle.
};


// Asignar evento de clic al botón "Buscar".
document.querySelector("#btnSearch").addEventListener("click", buscar);


//Función para mostrar 'datos-json' después de eliminar el dato 'filtrado'.
inputIngreso.addEventListener("input", () => {
  const searchTerm = inputIngreso.value.trim();
  if (searchTerm === "") {
    fetch("./data/data.json")
      .then((res) => res.json())
      .then((data) => mostrarProductos(data))
      .catch((err) => console.log(err));
  }
});


// Función para guardar en el local storage.
function guardarEnLocalStorage(elemento) {
  let productos = JSON.parse(localStorage.getItem("productos")) || [];
  productos.push(elemento);
  localStorage.setItem("productos", JSON.stringify(productos));
}


//Funcion para agregar datos en el Local Storage y + el boton: borrar + sweetAlert.
function asignarEventosCompra() {
  document.querySelectorAll(".btn-comprar").forEach((btn) => {
    btn.addEventListener("click", () => {
      const nombre = btn.getAttribute("data-nombre");
      const precio = btn.getAttribute("data-precio");
      const productosLS = JSON.parse(localStorage.getItem("productos")) || [];
      const productoExistente = productosLS.find(producto => producto.nombre === nombre && producto.precio === precio);
      
      // Comprobar si el producto ya existe en el carrito.
      if (productoExistente) {
        Swal.fire({
          title: "Este producto ya se encuentra en el carrito de compras o ha sido añadido previamente.",
          icon: "warning",
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
        });
        return;
      }
      
      // Crear elemento de lista para el producto en el carrito.
      const itemCarrito = document.createElement("li");
      let cantidad = 1;
      const id = productosLS.length;
      itemCarrito.setAttribute("data-id", id);
      itemCarrito.innerHTML = `
      <div class="row">
        <span class="col">${nombre} </span>
        <span class="col"> $${precio} </span>
        <div class="col">
          <div class="row">
            <span class="cantidad col">${cantidad}</span>
            <button class="btn-agregar btn btn-secondary col">+</button>
            <button class="btn-eliminar btn btn-secondary col">-</button>
          </div>
        </div>
        <div class="col text-center">
          <button class="btn-borrar btn btn-danger" data-id="${id}">x</button>
        </div>
      </div>`;

      // Agregar el elemento al carrito.
      carrito.appendChild(itemCarrito);
      total += parseFloat(precio);
      totalSpan.innerHTML = total.toFixed(2);

      const btnAgregar = itemCarrito.querySelector(".btn-agregar");
      // Manejar evento de clic en el botón de agregar.
      btnAgregar.addEventListener("click", () => {
        cantidad++;
        const cantidadSpan = itemCarrito.querySelector(".cantidad");
        cantidadSpan.innerHTML = cantidad;
        total += parseFloat(precio);
        totalSpan.innerHTML = total.toFixed(2);
        // Crear un nuevo objeto de producto actualizado.
        const nuevoProducto = {
          nombre: nombre,
          precio: precio,
          cantidad: cantidad,
          id: id
        };
        guardarEnLocalStorage(nuevoProducto);
      });

      const btnEliminar = itemCarrito.querySelector(".btn-eliminar");
      // Manejar evento de clic en el botón de eliminar.
      btnEliminar.addEventListener("click", () => {
        if (cantidad > 1) {
          cantidad--;
          const cantidadSpan = itemCarrito.querySelector(".cantidad");
          cantidadSpan.innerHTML = cantidad;
          total -= parseFloat(precio);
          totalSpan.innerHTML = total.toFixed(2);
          // Crear un nuevo objeto de producto actualizado
          const nuevoProducto = {
            nombre: nombre,
            precio: precio,
            cantidad: cantidad,
            id: id
          };
          guardarEnLocalStorage(nuevoProducto);
        }
      });

      const btnBorrar = itemCarrito.querySelector(".btn-borrar");
      // Manejar evento de clic en el botón de borrar.
      btnBorrar.addEventListener("click", (event) => {
        const id = event.target.getAttribute("data-id");
        const precioItem = parseFloat(precio) * cantidad;
        total -= precioItem;
        totalSpan.innerHTML = total.toFixed(2);
        
        // Eliminar el elemento del DOM.
        const elementoEliminar = document.querySelector(`li[data-id="${id}"]`);
        elementoEliminar.remove();

        // Eliminar el elemento del almacenamiento local.
        const productosLS = JSON.parse(localStorage.getItem("productos"));
        const productosActualizados = productosLS.filter(producto => !(producto.nombre === nombre && producto.precio === precio && producto.id == id));
        localStorage.setItem("productos", JSON.stringify(productosActualizados));
      });

      const nuevoProducto = {
        nombre: nombre,
        precio: precio,
        cantidad: cantidad,
        id: id
      };
      guardarEnLocalStorage(nuevoProducto);
    });
  });
}


// Vaciar carrito - vacía los datos almacenados en el 'Local Storage'- productos.
document.querySelector('#boton-vaciar').addEventListener('click', function() {
localStorage.removeItem('productos');
});


// Selecciona el botón de cerrar sesión.
const cerrarSesionBtn = document.getElementById('cerrarSesion');

// Agrega un event listener al botón.
cerrarSesionBtn.addEventListener('click', (event) => {
  // Previene el comportamiento predeterminado del botón (redireccionar a otra página).
  event.preventDefault();

  // Muestra un mensaje de confirmación con sweetalert y un icono de loader.
  Swal.fire({
    title: '¿Está seguro/a de que desea cerrar sesión?',
    showDenyButton: true,
    confirmButtonText: 'Si',
    denyButtonText: `Continuar comprando`,
    onBeforeOpen: () => {
      Swal.showLoading(); // Muestra el icono de loader.
    }
  }).then((result) => {
    if (result.isConfirmed) {
      // Si el usuario confirma el cierre de sesión, redirige a index.html después de 2 segundos.
      setTimeout(() => {
        window.location.href = "index.html";
      }, 1000);
    } else if (result.isDenied) {
      // Si el usuario decide continuar comprando, no hace nada.
    }
  })
  .catch((error) => {
    // Manejar cualquier error que ocurra durante la ejecución de SweetAlert.
    console.error(error);
  });
});


// Función que elimina los datos del Local Storage.
function clearLocalStorage() {
  localStorage.removeItem('productos');
}

// Detectar el evento 'beforeunload' para la ventana.
window.addEventListener('beforeunload', function(event) {
  clearLocalStorage();
});




