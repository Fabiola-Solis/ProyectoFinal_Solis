/*FIT-MARKET 
Mercado y/o tienda virtual enfocada en la venta minorista de productos relacionados con la salud y nutrición.
Incluyendo proteínas, vitaminas, anábolicos, entre otros. Con servicio de 'Delivery' para los clientes del GAM, en: 
San José, Costa Rica.
*/


//// pag. 'Contact.html' ////
/*Aparece un formulario de : 'Contacto', que incluye varios campos o 'input':

    - Nombre.
    - Tema.
    - Mensaje.
    - Botón: 'Enviar mensaje'
        > Si se le da clic al botón antes de llenar los campos, aparece un mensaje que dice: 'Por favor, complete todos los campos antes de continuar.'.
        > Si se llenan los campos, y seguidamente se le da clic al botón, el mensaje dice: '¡Gracias! Su mensaje ha sido enviado'
*/



//// CONTACT ////
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('enviar').addEventListener('click', (event) => {
      event.preventDefault(); // Evita el envío del formulario

      // Obtener los valores de los campos de entrada
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const subject = document.getElementById('subject').value;
      const message = document.getElementById('message').value;

      // Verificar si los campos están vacíos
      if (name === '' || email === '' || subject === '' || message === '') {
        Swal.fire({
          title: 'Por favor, complete todos los campos antes de continuar.',
          icon: 'error',
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
        });
      } else {
        // Mostrar mensaje de confirmación utilizando SweetAlert
        Swal.fire('¡Gracias!', 'Su mensaje ha sido enviado', 'success');
        // Aquí puedes realizar otras acciones, como enviar el formulario a través de AJAX
      }
    });
  });